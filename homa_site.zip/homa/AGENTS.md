<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# Project rules

- The site is Persian and RTL (`<html lang="fa" dir="rtl">`); write UI copy in Persian and use logical layout (no hard-coded left/right assumptions). Why: the audience is Iranian investors.
- All proposal copy lives in `src/content/homa.ts`; pages render from it. Why: one place to edit the pitch.
- Shared header/footer render in `src/routes/__root.tsx`; each pitch section is its own route (`/`, `/product`, `/business`, `/roadmap`, `/invest`). Why: crawlable, shareable pages.
- Investor accounts use Lovable Cloud auth; signed-in pages live under `src/routes/_authenticated/` (client-only gate). Investor data is read/written from the browser client with RLS (owner or `admin` role via `has_role`). Why: no server secrets needed for this flow.
- Roles live only in `public.user_roles`; never infer admin from profile data or client storage.
- Product screenshots are the founder's design mockups stored as Lovable asset pointers in `src/assets/*.asset.json`.
