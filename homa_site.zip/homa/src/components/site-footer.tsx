import { Link } from "@tanstack/react-router";
import { HomaLogo } from "@/components/homa-logo";
import { presenters } from "@/content/homa";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-3 md:px-6">
        <div className="space-y-4">
          <HomaLogo light />
          <p className="max-w-xs text-sm leading-7 text-ink-foreground/70">
            هما؛ از جست‌وجوی خانه تا شکل‌گیری یک اکوسیستم هوشمند در بازار مسکن ایران.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <Link to="/product" className="text-ink-foreground/75 hover:text-ink-foreground">محصول</Link>
          <Link to="/business" className="text-ink-foreground/75 hover:text-ink-foreground">مدل کسب‌وکار</Link>
          <Link to="/roadmap" className="text-ink-foreground/75 hover:text-ink-foreground">نقشه راه</Link>
          <Link to="/invest" className="text-ink-foreground/75 hover:text-ink-foreground">سرمایه‌گذاری</Link>
        </div>
        <div className="space-y-2 text-sm text-ink-foreground/70">
          <p className="font-semibold text-ink-foreground">ارائه‌دهندگان طرح و تماس</p>
          {presenters.map((p) => (
            <p key={p.phone}>
              {p.name}:{" "}
              <a href={`tel:${p.phone}`} className="text-ink-foreground hover:text-highlight">
                {p.phoneFa}
              </a>
            </p>
          ))}
          <p>وضعیت: مرحله ایده‌پردازی و جذب سرمایه اولیه</p>
          <p className="pt-2 text-xs leading-6 text-ink-foreground/50">
            تصاویر محصول، طرح‌های مفهومی هستند. قابلیت‌ها برنامه‌ریزی‌شده‌اند و هیچ بازدهی یا درآمدی تضمین نمی‌شود.
          </p>
        </div>
      </div>
    </footer>
  );
}
