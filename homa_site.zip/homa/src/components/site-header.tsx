import { Link } from "@tanstack/react-router";
import { Menu, UserRound } from "lucide-react";
import { useState } from "react";
import { HomaLogo } from "@/components/homa-logo";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/use-auth";

const nav = [
  { to: "/", label: "معرفی" },
  { to: "/product", label: "محصول" },
  { to: "/business", label: "مدل کسب‌وکار" },
  { to: "/roadmap", label: "نقشه راه" },
  { to: "/invest", label: "سرمایه‌گذاری" },
] as const;

export function SiteHeader() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 md:px-6">
        <Link to="/" aria-label="هما، صفحه اصلی">
          <HomaLogo />
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.to === "/" }}
              className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground data-[status=active]:bg-primary-soft data-[status=active]:text-accent-foreground"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild variant={user ? "soft" : "hero"} size="sm" className="h-9 px-4">
            <Link to={user ? "/dashboard" : "/auth"}>
              <UserRound />
              {user ? "پنل سرمایه‌گذار" : "ورود سرمایه‌گذار"}
            </Link>
          </Button>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" aria-label="منو">
                <Menu />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <SheetTitle className="mb-6">
                <HomaLogo />
              </SheetTitle>
              <nav className="flex flex-col gap-1">
                {nav.map((item) => (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setOpen(false)}
                    activeOptions={{ exact: item.to === "/" }}
                    className="rounded-lg px-3 py-3 text-base font-medium text-muted-foreground data-[status=active]:bg-primary-soft data-[status=active]:text-accent-foreground"
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
