import { cn } from "@/lib/utils";

export function HomaMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" aria-hidden="true" className={cn("h-8 w-8", className)}>
      <path
        d="M16 3 4 11.5V28h8.5v-8.5h7V28H28V11.5L16 3Z"
        className="fill-primary"
      />
      <path d="M16 3 28 11.5V28h-8.5v-8.5H16V3Z" className="fill-primary-deep" opacity="0.35" />
    </svg>
  );
}

export function HomaLogo({ className, light }: { className?: string; light?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2", className)} dir="ltr">
      <HomaMark />
      <span
        className={cn(
          "text-2xl font-extrabold tracking-tight",
          light ? "text-ink-foreground" : "text-foreground",
        )}
      >
        Homa
      </span>
    </span>
  );
}
