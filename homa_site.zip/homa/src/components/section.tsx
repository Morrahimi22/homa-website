import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function SectionHeading({
  kicker,
  title,
  text,
  className,
}: {
  kicker?: string;
  title: string;
  text?: string;
  className?: string;
}) {
  return (
    <div className={cn("max-w-2xl space-y-3", className)}>
      {kicker && (
        <span className="inline-flex items-center gap-2 text-sm font-semibold text-primary">
          <span className="h-px w-6 bg-primary" />
          {kicker}
        </span>
      )}
      <h2 className="text-balance-fa text-3xl font-extrabold leading-tight md:text-4xl">{title}</h2>
      {text && <p className="text-base leading-8 text-muted-foreground">{text}</p>}
    </div>
  );
}

export function PageHero({ kicker, title, text, children }: { kicker: string; title: string; text: string; children?: ReactNode }) {
  return (
    <section className="relative overflow-hidden border-b border-border bg-gradient-soft">
      <div className="grid-dots absolute inset-0 opacity-60" />
      <div className="relative mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
        <div className="animate-rise max-w-3xl space-y-5">
          <span className="inline-flex rounded-full bg-primary-soft px-3 py-1 text-xs font-semibold text-accent-foreground">
            {kicker}
          </span>
          <h1 className="text-balance-fa text-4xl font-black leading-[1.3] md:text-5xl">{title}</h1>
          <p className="text-lg leading-9 text-muted-foreground">{text}</p>
          {children}
        </div>
      </div>
    </section>
  );
}

export function Notice({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-2xl border border-highlight/40 bg-highlight/10 p-5 text-sm leading-7 text-highlight-foreground">
      {children}
    </div>
  );
}
