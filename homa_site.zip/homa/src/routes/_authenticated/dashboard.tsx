import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { CheckCircle2, LogOut } from "lucide-react";
import { useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { interestAreas, investmentRanges, investorTypes } from "@/content/homa";
import { allInterestsQuery, isAdminQuery, myInterestQuery, type InvestorInterest } from "@/lib/investor-queries";
import { cn } from "@/lib/utils";

const statusLabels: Record<string, string> = {
  new: "دریافت شد",
  contacted: "در حال گفت‌وگو",
  closed: "بسته شد",
};

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "پنل سرمایه‌گذار | هما" },
      { name: "description", content: "ثبت و ویرایش علاقه به سرمایه‌گذاری در استارتاپ هما." },
      { name: "robots", content: "noindex" },
    ],
  }),
  loader: async ({ context }) => {
    const userId = context.user.id;
    const [, isAdmin] = await Promise.all([
      context.queryClient.ensureQueryData(myInterestQuery(userId)),
      context.queryClient.ensureQueryData(isAdminQuery(userId)),
    ]);
    if (isAdmin) await context.queryClient.ensureQueryData(allInterestsQuery());
    return { userId, email: context.user.email ?? "" };
  },
  component: Dashboard,
});

function Dashboard() {
  const { userId, email } = Route.useLoaderData();
  const { data: isAdmin } = useSuspenseQuery(isAdminQuery(userId));
  const navigate = useNavigate();

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 md:px-6 md:py-16">
      <div className="mb-10 flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-sm text-muted-foreground" dir="ltr">{email}</p>
          <h1 className="mt-1 text-3xl font-extrabold">پنل سرمایه‌گذار</h1>
        </div>
        <Button variant="outline" className="rounded-xl" onClick={signOut}>
          <LogOut /> خروج
        </Button>
      </div>
      <InterestForm userId={userId} />
      {isAdmin && <AdminList />}
    </div>
  );
}

function InterestForm({ userId }: { userId: string }) {
  const qc = useQueryClient();
  const { data: existing } = useSuspenseQuery(myInterestQuery(userId));
  const [form, setForm] = useState({
    full_name: existing?.full_name ?? "",
    phone: existing?.phone ?? "",
    company: existing?.company ?? "",
    investor_type: existing?.investor_type ?? "individual",
    investment_range: existing?.investment_range ?? investmentRanges[0] ?? "",
    interest_areas: existing?.interest_areas ?? [],
    message: existing?.message ?? "",
  });

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("investor_interests")
        .upsert({ ...form, user_id: userId }, { onConflict: "user_id" });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("علاقه شما ثبت شد. ارائه‌دهندگان طرح با شما تماس می‌گیرند.");
      qc.invalidateQueries({ queryKey: ["investor-interest", userId] });
      qc.invalidateQueries({ queryKey: ["investor-interests-all"] });
    },
    onError: () => toast.error("ذخیره انجام نشد. دوباره تلاش کنید."),
  });

  function toggleArea(a: string) {
    setForm((f) => ({
      ...f,
      interest_areas: f.interest_areas.includes(a) ? f.interest_areas.filter((x) => x !== a) : [...f.interest_areas, a],
    }));
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (form.full_name.trim().length < 2) {
      toast.error("نام و نام خانوادگی را وارد کنید.");
      return;
    }
    save.mutate();
  }

  return (
    <form onSubmit={onSubmit} className="rounded-3xl border border-border bg-card p-6 shadow-card md:p-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold">ثبت علاقه به سرمایه‌گذاری</h2>
          <p className="mt-1 text-sm text-muted-foreground">این اطلاعات فقط برای شما و ارائه‌دهندگان طرح قابل مشاهده است.</p>
        </div>
        {existing && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-success-soft px-3 py-1 text-xs font-semibold text-success">
            <CheckCircle2 className="h-3.5 w-3.5" /> وضعیت: {statusLabels[existing.status] ?? existing.status}
          </span>
        )}
      </div>

      <div className="mt-8 grid gap-5 md:grid-cols-2">
        <Field label="نام و نام خانوادگی *" id="full_name">
          <Input id="full_name" required maxLength={100} value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} className="h-11 rounded-xl" />
        </Field>
        <Field label="شماره تماس" id="phone">
          <Input id="phone" dir="ltr" maxLength={20} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="h-11 rounded-xl text-right" />
        </Field>
        <Field label="شرکت یا مجموعه" id="company">
          <Input id="company" maxLength={120} value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} className="h-11 rounded-xl" />
        </Field>
        <Field label="نوع سرمایه‌گذار" id="investor_type">
          <Select value={form.investor_type} onValueChange={(v) => setForm({ ...form, investor_type: v })}>
            <SelectTrigger id="investor_type" className="h-11 rounded-xl">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {investorTypes.map((t) => (
                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="بازه سرمایه موردنظر" id="investment_range">
          <Select value={form.investment_range} onValueChange={(v) => setForm({ ...form, investment_range: v })}>
            <SelectTrigger id="investment_range" className="h-11 rounded-xl">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {investmentRanges.map((r) => (
                <SelectItem key={r} value={r}>{r}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
      </div>

      <div className="mt-6 space-y-3">
        <Label>حوزه‌های موردعلاقه</Label>
        <div className="flex flex-wrap gap-2">
          {interestAreas.map((a) => {
            const on = form.interest_areas.includes(a);
            return (
              <button
                key={a}
                type="button"
                aria-pressed={on}
                onClick={() => toggleArea(a)}
                className={cn(
                  "rounded-full border px-4 py-2 text-sm transition-colors",
                  on ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background hover:bg-muted",
                )}
              >
                {a}
              </button>
            );
          })}
        </div>
      </div>

      <Field label="پیام یا شرایط پیشنهادی" id="message" className="mt-6">
        <Textarea id="message" rows={4} maxLength={2000} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="rounded-xl" />
      </Field>

      <Button type="submit" variant="hero" size="xl" className="mt-8 w-full sm:w-auto" disabled={save.isPending}>
        {save.isPending ? "در حال ذخیره…" : existing ? "به‌روزرسانی اطلاعات" : "ثبت علاقه"}
      </Button>
    </form>
  );
}

function Field({ label, id, children, className }: { label: string; id: string; children: ReactNode; className?: string }) {
  return (
    <div className={cn("space-y-2", className)}>
      <Label htmlFor={id}>{label}</Label>
      {children}
    </div>
  );
}

function AdminList() {
  const qc = useQueryClient();
  const { data } = useSuspenseQuery(allInterestsQuery());
  const update = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("investor_interests").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["investor-interests-all"] }),
    onError: () => toast.error("تغییر وضعیت انجام نشد."),
  });
  const typeLabel = (v: string) => investorTypes.find((t) => t.value === v)?.label ?? v;

  return (
    <section className="mt-12">
      <h2 className="text-xl font-extrabold">همه درخواست‌های سرمایه‌گذاران ({data.length.toLocaleString("fa-IR")})</h2>
      <div className="mt-6 space-y-4">
        {data.length === 0 && <p className="text-sm text-muted-foreground">هنوز درخواستی ثبت نشده است.</p>}
        {data.map((r: InvestorInterest) => (
          <div key={r.id} className="rounded-2xl border border-border bg-card p-5 shadow-card">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-bold">{r.full_name}</p>
                <p className="text-sm text-muted-foreground">
                  {typeLabel(r.investor_type)}
                  {r.company && ` · ${r.company}`} · {r.investment_range}
                </p>
                {r.phone && <p className="mt-1 text-sm" dir="ltr">{r.phone}</p>}
              </div>
              <Select value={r.status} onValueChange={(status) => update.mutate({ id: r.id, status })}>
                <SelectTrigger className="h-9 w-40 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(statusLabels).map(([v, l]) => (
                    <SelectItem key={v} value={v}>{l}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {r.interest_areas.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {r.interest_areas.map((a) => (
                  <span key={a} className="rounded-md bg-primary-soft px-2 py-1 text-xs text-accent-foreground">{a}</span>
                ))}
              </div>
            )}
            {r.message && <p className="mt-3 text-sm leading-7 text-muted-foreground">{r.message}</p>}
            <p className="mt-3 text-xs text-muted-foreground">{new Date(r.created_at).toLocaleDateString("fa-IR")}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
