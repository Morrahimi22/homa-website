import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { HomaLogo } from "@/components/homa-logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

function safePath(value: unknown): string {
  return typeof value === "string" && value.startsWith("/") && !value.startsWith("//") ? value : "/dashboard";
}

export const Route = createFileRoute("/auth")({
  validateSearch: (search: Record<string, unknown>): { redirect?: string | undefined } => ({
    redirect: typeof search["redirect"] === "string" ? search["redirect"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "ورود سرمایه‌گذاران | هما" },
      { name: "description", content: "ورود یا ساخت حساب سرمایه‌گذار برای ثبت علاقه به سرمایه‌گذاری در استارتاپ هما." },
      { property: "og:title", content: "ورود سرمایه‌گذاران هما" },
      { property: "og:description", content: "حساب سرمایه‌گذار بسازید و علاقه خود را ثبت کنید." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { redirect } = Route.useSearch();
  const target = safePath(redirect);
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: target });
    });
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" && session) navigate({ to: target });
    });
    return () => data.subscription.unsubscribe();
  }, [navigate, target]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}${target}` },
        });
        if (error) throw error;
        if (!data.session) setSent(true);
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      toast.error(
        msg.includes("Invalid login") ? "ایمیل یا رمز عبور نادرست است." : msg.includes("already") ? "این ایمیل قبلاً ثبت شده؛ وارد شوید." : "خطایی رخ داد. دوباره تلاش کنید.",
      );
    } finally {
      setBusy(false);
    }
  }

  async function oauth(provider: "google") {
    const result = await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin + "/auth" });
    if (result.error) {
      toast.error("ورود انجام نشد. دوباره تلاش کنید.");
      return;
    }
    if (result.redirected) return;
    navigate({ to: target });
  }

  return (
    <section className="grid-dots flex min-h-[80vh] items-center justify-center px-4 py-16">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-6 shadow-elevated sm:p-8">
        <div className="mb-6 flex flex-col items-center gap-3 text-center">
          <HomaLogo />
          <h1 className="text-2xl font-extrabold">حساب سرمایه‌گذار</h1>
          <p className="text-sm leading-7 text-muted-foreground">برای ثبت علاقه به سرمایه‌گذاری در هما وارد شوید یا حساب بسازید.</p>
        </div>

        {sent ? (
          <div className="space-y-3 rounded-2xl bg-primary-soft p-6 text-center">
            <p className="font-bold">ایمیل تأیید ارسال شد</p>
            <p className="text-sm leading-7 text-muted-foreground">
              روی لینک ارسال‌شده به <span dir="ltr">{email}</span> بزنید تا حساب شما فعال شود. پوشه هرزنامه را هم بررسی کنید.
            </p>
            <Button variant="link" onClick={() => { setSent(false); setMode("signin"); }}>
              بازگشت به ورود
            </Button>
          </div>
        ) : (
          <>
            <Tabs value={mode} onValueChange={(v) => setMode(v as "signin" | "signup")} className="mb-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signup">ساخت حساب</TabsTrigger>
                <TabsTrigger value="signin">ورود</TabsTrigger>
              </TabsList>
            </Tabs>

            <form onSubmit={onSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">ایمیل</Label>
                <Input id="email" type="email" dir="ltr" required value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">رمز عبور</Label>
                <Input id="password" type="password" dir="ltr" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="h-11 rounded-xl" />
              </div>
              <Button type="submit" variant="hero" size="xl" className="w-full" disabled={busy}>
                {busy ? "لطفاً صبر کنید…" : mode === "signup" ? "ساخت حساب" : "ورود"}
              </Button>
            </form>

            <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
              <span className="h-px flex-1 bg-border" /> یا <span className="h-px flex-1 bg-border" />
            </div>

            <div className="space-y-3">
              <Button type="button" variant="outline" size="xl" className="w-full" onClick={() => oauth("google")}>
                ادامه با گوگل
              </Button>
            </div>
          </>
        )}
      </div>
    </section>
  );
}
