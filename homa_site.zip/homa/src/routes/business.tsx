import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { Notice, PageHero, SectionHeading } from "@/components/section";
import { advantages, marketStages, revenue } from "@/content/homa";

export const Route = createFileRoute("/business")({
  head: () => ({
    meta: [
      { title: "مدل کسب‌وکار هما | درآمد، بازار هدف و مزیت رقابتی" },
      { name: "description", content: "منابع درآمدی پیشنهادی هما در سه مرحله، استراتژی ورود به بازار تهران و توسعه ملی، و مزیت‌های رقابتی هدف‌گذاری‌شده." },
      { property: "og:title", content: "مدل کسب‌وکار هما" },
      { property: "og:description", content: "درآمد متنوع، ورود از تهران و توسعه مرحله‌ای." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BusinessPage,
});

function BusinessPage() {
  return (
    <>
      <PageHero
        kicker="مدل درآمدزایی"
        title="چند منبع درآمد، به‌جای وابستگی به یکی"
        text="برای پایداری اقتصادی، هما به‌تدریج منابع درآمدی متنوعی ایجاد می‌کند. میزان واقعی درآمد پس از راه‌اندازی و اعتبارسنجی بازار مشخص می‌شود."
      />

      <section className="mx-auto max-w-7xl px-4 py-20 md:px-6 md:py-28">
        <div className="grid gap-6 lg:grid-cols-3">
          {revenue.map((r, idx) => (
            <div key={r.stage} className="flex flex-col rounded-3xl border border-border bg-card p-6 shadow-card md:p-8">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-extrabold">{r.stage}</h2>
                <span className="rounded-full bg-primary-soft px-3 py-1 text-xs font-bold text-accent-foreground">
                  گام {(idx + 1).toLocaleString("fa-IR")}
                </span>
              </div>
              <ul className="mt-6 space-y-4">
                {r.items.map((it) => (
                  <li key={it.title} className="border-t border-border pt-4">
                    <p className="font-bold">{it.title}</p>
                    <p className="mt-1 text-sm leading-7 text-muted-foreground">{it.text}</p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-8">
          <Notice>
            درآمد اشتراک مشاوران، معرفی مشتری و قرارداد دیجیتال جداگانه محاسبه می‌شود تا درآمد یک خدمت چند بار در گزارش مالی ثبت نشود.
          </Notice>
        </div>
      </section>

      <section className="bg-gradient-soft py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-4 md:px-6">
          <SectionHeading
            kicker="استراتژی ورود به بازار"
            title="شروع از تهران، گسترش براساس عملکرد واقعی"
            text="توسعه جغرافیایی براساس هزینه جذب مشتری، درآمد هر کاربر و توان عملیاتی تیم انجام می‌شود."
          />
          <div className="relative mt-12 grid gap-6 md:grid-cols-3">
            {marketStages.map((s, i) => (
              <div key={s.title} className="relative rounded-3xl border border-border bg-card p-6 shadow-card">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-brand text-lg font-black text-primary-foreground shadow-glow">
                  {(i + 1).toLocaleString("fa-IR")}
                </span>
                <h3 className="mt-5 text-lg font-bold">{s.title}</h3>
                <ul className="mt-4 space-y-2.5">
                  {s.items.map((it) => (
                    <li key={it} className="flex gap-2 text-sm leading-7 text-muted-foreground">
                      <Check className="mt-1.5 h-4 w-4 shrink-0 text-primary" />
                      {it}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 md:px-6 md:py-28">
        <SectionHeading
          kicker="مزیت رقابتی پیشنهادی"
          title="تجربه‌ای یکپارچه‌تر از رقبا"
          text="این موارد مزیت‌های هدف‌گذاری‌شده هستند و اثبات عملی آن‌ها به اجرای محصول و استقبال بازار وابسته است."
        />
        <div className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {advantages.map((a) => (
            <div key={a} className="rounded-2xl border border-border bg-card p-5 text-sm font-semibold leading-7 shadow-card">
              {a}
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
