import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Building2, Check, MapPin, Sparkles, Users } from "lucide-react";
import heroImg from "@/assets/hero-tehran.jpg";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/section";
import { facts, mission, problems, showcases } from "@/content/homa";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "هما (HOMA) | پروپوزال سرمایه‌گذاری پلتفرم خدمات ملکی" },
      {
        name: "description",
        content: "هما، پلتفرم یکپارچه خرید، فروش، اجاره، پیش‌فروش و خدمات ملکی؛ آغاز از تهران و گسترش تدریجی در ایران. دعوت به سرمایه‌گذاری اولیه.",
      },
      { property: "og:title", content: "هما (HOMA) | پروپوزال سرمایه‌گذاری" },
      { property: "og:description", content: "از جست‌وجوی خانه تا یک اکوسیستم هوشمند در بازار مسکن ایران." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const pillars = [
  { icon: Building2, title: "خرید، فروش و اجاره", text: "جست‌وجوی پیشرفته، نقشه و صفحه کامل هر ملک" },
  { icon: Users, title: "پنل مشاوران", text: "ابزار حرفه‌ای برای مشاوران املاک تأییدشده" },
  { icon: Sparkles, title: "دستیار هوشمند", text: "پیشنهاد خانه براساس بودجه و منطقه" },
  { icon: MapPin, title: "پیش‌فروش و ساخت", text: "معرفی پروژه‌ها و خدمات ساختمانی" },
];

function Index() {
  return (
    <>
      {/* Hero */}
      <section className="relative isolate overflow-hidden bg-ink">
        <img
          src={heroImg}
          alt="منظره برج‌های مسکونی تهران و رشته‌کوه البرز در غروب"
          width={1600}
          height={912}
          className="absolute inset-0 -z-10 h-full w-full object-cover"
        />
        <div className="bg-hero-overlay absolute inset-0 -z-10" />
        <div className="mx-auto flex min-h-[640px] max-w-7xl flex-col justify-end px-4 pb-14 pt-32 md:min-h-[720px] md:justify-center md:px-6 md:pb-0 md:pt-0">
          <div className="animate-rise max-w-2xl space-y-6 text-ink-foreground">
            <span className="inline-flex items-center gap-2 rounded-full border border-ink-foreground/25 bg-ink-foreground/10 px-3 py-1 text-xs font-semibold backdrop-blur">
              <span className="h-2 w-2 rounded-full bg-highlight" />
              مرحله ایده‌پردازی و جذب سرمایه اولیه
            </span>
            <h1 className="text-balance-fa text-4xl font-black leading-[1.35] md:text-6xl md:leading-[1.25]">
              از جست‌وجوی خانه تا یک
              <span className="text-highlight"> اکوسیستم هوشمند </span>
              در بازار مسکن ایران
            </h1>
            <p className="max-w-xl text-base leading-8 text-ink-foreground/80 md:text-lg md:leading-9">
              هما بستری یکپارچه برای خرید، فروش، اجاره، پیش‌فروش و خدمات ملکی است؛ فراتر از یک سایت ثبت آگهی.
              فعالیت از تهران آغاز می‌شود و به‌تدریج به سراسر ایران گسترش می‌یابد.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild variant="hero" size="xl">
                <Link to="/invest">
                  اعلام علاقه به سرمایه‌گذاری
                  <ArrowLeft />
                </Link>
              </Button>
              <Button asChild variant="heroGhost" size="xl">
                <Link to="/product">مشاهده طرح محصول</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Facts */}
      <section className="relative z-10 mx-auto -mt-10 max-w-7xl px-4 md:px-6">
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border shadow-elevated md:grid-cols-4">
          {facts.map((f) => (
            <div key={f.label} className="bg-card p-5 md:p-6">
              <p className="text-xs text-muted-foreground">{f.label}</p>
              <p className="mt-2 text-sm font-bold leading-6 md:text-base">{f.value}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Summary */}
      <section className="mx-auto grid max-w-7xl gap-12 px-4 py-20 md:grid-cols-2 md:px-6 md:py-28">
        <SectionHeading
          kicker="خلاصه اجرایی"
          title="خدمات ملکی ساده‌تر، شفاف‌تر و در دسترس‌تر"
          text="در شرایطی که خرید و اجاره مسکن پیچیده، زمان‌بر و پرهزینه شده، هما با فناوری مسیر جست‌وجو، ارتباط با مشاور، قرارداد و خدمات جانبی را در یک جا جمع می‌کند."
        />
        <div className="grid gap-4 sm:grid-cols-2">
          {pillars.map(({ icon: Icon, title, text }) => (
            <div key={title} className="rounded-2xl border border-border bg-card p-5 shadow-card">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary-soft text-primary">
                <Icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 font-bold">{title}</h3>
              <p className="mt-1 text-sm leading-7 text-muted-foreground">{text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Problems */}
      <section className="bg-gradient-soft py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-4 md:px-6">
          <SectionHeading kicker="مسئله" title="هفت گره بازار مسکن که هما هدف گرفته" />
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {problems.map((p, i) => (
              <div key={p.title} className="rounded-2xl border border-border bg-card p-6 shadow-card">
                <span className="text-3xl font-black text-primary/25">{(i + 1).toLocaleString("fa-IR")}</span>
                <h3 className="mt-2 font-bold">{p.title}</h3>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{p.text}</p>
              </div>
            ))}
            <div className="flex flex-col justify-between rounded-2xl bg-gradient-brand p-6 text-primary-foreground shadow-glow">
              <p className="text-lg font-bold leading-8">هما با توسعه مرحله‌ای، این مشکلات را یکی‌یکی هدف قرار می‌دهد.</p>
              <Link to="/product" className="mt-6 inline-flex items-center gap-2 text-sm font-semibold">
                راهکار پیشنهادی <ArrowLeft className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Product preview */}
      <section className="mx-auto max-w-7xl px-4 py-20 md:px-6 md:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading kicker="طرح محصول" title="نگاهی به تجربه کاربری هما" text="طرح‌های مفهومی چهار بخش اصلی پلتفرم." />
          <Button asChild variant="soft" size="xl">
            <Link to="/product">
              همه بخش‌ها <ArrowLeft />
            </Link>
          </Button>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {showcases.map((s) => (
            <Link
              key={s.id}
              to="/product"
              hash={s.id}
              className="group overflow-hidden rounded-3xl border border-border bg-card shadow-card transition-shadow hover:shadow-elevated"
            >
              <div className="aspect-[16/10] overflow-hidden bg-muted">
                <img
                  src={s.images[0]?.url}
                  alt={s.images[0]?.alt ?? s.title}
                  loading="lazy"
                  className="h-full w-full object-cover object-top transition-transform duration-500 group-hover:scale-[1.03]"
                />
              </div>
              <div className="p-6">
                <p className="text-xs font-semibold text-primary">{s.kicker}</p>
                <h3 className="mt-1 text-xl font-bold">{s.title}</h3>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Mission */}
      <section className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="grid gap-10 rounded-3xl bg-ink p-8 text-ink-foreground md:grid-cols-[1fr_1.4fr] md:p-14">
          <div className="space-y-4">
            <span className="text-sm font-semibold text-highlight">چشم‌انداز</span>
            <h2 className="text-balance-fa text-3xl font-extrabold leading-tight">
              یکی از پلتفرم‌های جامع و قابل‌اعتماد خدمات ملکی در ایران
            </h2>
            <p className="leading-8 text-ink-foreground/70">
              ارتباط مؤثر میان خریداران، مستأجران، مالکان، مشاوران، سازندگان، پیمانکاران و مؤسسات مالی.
            </p>
          </div>
          <ul className="grid gap-3 sm:grid-cols-2">
            {mission.map((m) => (
              <li key={m} className="flex gap-3 rounded-xl bg-ink-foreground/5 p-4 text-sm leading-7">
                <Check className="mt-1 h-4 w-4 shrink-0 text-highlight" />
                {m}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-4xl px-4 pt-24 text-center md:px-6">
        <h2 className="text-balance-fa text-3xl font-extrabold leading-tight md:text-4xl">
          در ساخت نسخه اولیه هما همراه شوید
        </h2>
        <p className="mx-auto mt-4 max-w-2xl leading-8 text-muted-foreground">
          همکاری برای اعتبارسنجی ایده، ساخت نسخه اولیه، آغاز فعالیت در تهران و توسعه تدریجی به یک پلتفرم ملی.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild variant="hero" size="xl">
            <Link to="/invest">پیشنهاد سرمایه‌گذاری</Link>
          </Button>
          <Button asChild variant="outline" size="xl" className="rounded-xl">
            <Link to="/roadmap">نقشه راه</Link>
          </Button>
        </div>
      </section>
    </>
  );
}
