import { createFileRoute } from "@tanstack/react-router";
import { Check, Clock, Expand } from "lucide-react";
import { useState } from "react";
import { Notice, PageHero, SectionHeading } from "@/components/section";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { futureModules, mvp, showcases } from "@/content/homa";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/product")({
  head: () => ({
    meta: [
      { title: "محصول هما | طرح‌های جست‌وجو، دستیار هوشمند و پیش‌فروش" },
      { name: "description", content: "طرح مفهومی بخش‌های اصلی هما: جست‌وجو و جزئیات ملک، دستیار هوشمند، پروژه‌های پیش‌فروش، خانه‌یابی و خوابگاه دانشجویی." },
      { property: "og:title", content: "محصول هما | پلتفرم جامع خدمات ملکی" },
      { property: "og:description", content: "نگاهی به طرح‌های تجربه کاربری هما و قابلیت‌های برنامه‌ریزی‌شده." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductPage,
});

function ProductPage() {
  const [preview, setPreview] = useState<{ url: string; alt: string } | null>(null);

  return (
    <>
      <PageHero
        kicker="راهکار پیشنهادی"
        title="پلتفرم جامع هما، بخش به بخش"
        text="این تصاویر طرح‌های مفهومی تجربه کاربری هما هستند و نشان می‌دهند محصول نهایی به چه سمتی می‌رود. محصول هنوز ساخته نشده است."
      />

      <div className="mx-auto max-w-7xl space-y-24 px-4 py-20 md:space-y-32 md:px-6 md:py-28">
        {showcases.map((s, idx) => (
          <section key={s.id} id={s.id} className="scroll-mt-24">
            <div className={cn("grid items-center gap-10 lg:grid-cols-[1fr_1.5fr]", idx % 2 === 1 && "lg:grid-cols-[1.5fr_1fr]")}>
              <div className={cn("space-y-6", idx % 2 === 1 && "lg:order-2")}>
                <SectionHeading kicker={s.kicker} title={s.title} text={s.text} />
                <ul className="space-y-3">
                  {s.points.map((p) => (
                    <li key={p} className="flex gap-3 text-sm leading-7">
                      <span className="mt-1 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary-soft text-primary">
                        <Check className="h-3 w-3" />
                      </span>
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
              <div className={cn("grid gap-4", s.images.length > 1 && "sm:grid-cols-2", s.images.length === 3 && "sm:grid-cols-2")}>
                {s.images.map((img, i) => (
                  <button
                    key={img.url}
                    type="button"
                    onClick={() => setPreview(img)}
                    className={cn(
                      "group relative overflow-hidden rounded-2xl border border-border bg-card text-right shadow-card transition-shadow hover:shadow-elevated",
                      s.images.length === 1 && "sm:col-span-2",
                      s.images.length === 3 && i === 0 && "sm:col-span-2",
                    )}
                    aria-label={`بزرگ‌نمایی: ${img.alt}`}
                  >
                    <img
                      src={img.url}
                      alt={img.alt}
                      loading="lazy"
                      className={cn("w-full object-cover object-top", s.images.length > 1 && "aspect-[4/3]")}
                    />
                    <span className="absolute bottom-3 left-3 flex h-9 w-9 items-center justify-center rounded-full bg-card/90 text-foreground opacity-0 shadow-card transition-opacity group-hover:opacity-100">
                      <Expand className="h-4 w-4" />
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </section>
        ))}
      </div>

      <section className="bg-gradient-soft py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-4 md:px-6">
          <SectionHeading kicker="برنامه توسعه" title="بخش‌هایی که در مراحل بعد اضافه می‌شوند" />
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {futureModules.map((m) => (
              <div key={m.title} className="rounded-2xl border border-border bg-card p-6 shadow-card">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-highlight/15 px-2.5 py-1 text-xs font-semibold text-highlight-foreground">
                  <Clock className="h-3 w-3" /> آینده
                </span>
                <h3 className="mt-4 font-bold">{m.title}</h3>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{m.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-20 md:grid-cols-2 md:px-6 md:py-28">
        <div className="space-y-6">
          <SectionHeading
            kicker="نسخه اولیه (MVP)"
            title="فقط قابلیت‌های ضروری، برای آزمایش تقاضای بازار"
            text="در نسخه اولیه لازم نیست همه قابلیت‌های بلندمدت ساخته شوند. هدف، سنجش تمایل مشاوران و کاربران است."
          />
          <Notice>
            انتخاب میان توسعه اختصاصی، زیرساخت آماده یا ترکیب آن‌ها پس از دریافت پیشنهاد فنی و مالی از تیم‌های توسعه انجام می‌شود.
          </Notice>
        </div>
        <ol className="grid gap-3 sm:grid-cols-2">
          {mvp.map((m, i) => (
            <li key={m} className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 text-sm font-medium shadow-card">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary text-xs font-bold text-primary-foreground">
                {(i + 1).toLocaleString("fa-IR")}
              </span>
              {m}
            </li>
          ))}
        </ol>
      </section>

      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-6xl p-2 sm:p-3">
          <DialogTitle className="sr-only">{preview?.alt}</DialogTitle>
          {preview && <img src={preview.url} alt={preview.alt} className="max-h-[85vh] w-full rounded-lg object-contain" />}
        </DialogContent>
      </Dialog>
    </>
  );
}
