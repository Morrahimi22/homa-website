import { createFileRoute } from "@tanstack/react-router";
import { ShieldAlert } from "lucide-react";
import { Notice, PageHero, SectionHeading } from "@/components/section";
import { kpis, phases, risks } from "@/content/homa";

export const Route = createFileRoute("/roadmap")({
  head: () => ({
    meta: [
      { title: "نقشه راه هما | فازها، شاخص‌ها و ریسک‌ها" },
      { name: "description", content: "پنج فاز توسعه هما از اعتبارسنجی تا گسترش ملی، شاخص‌های ارزیابی موفقیت و راهکار مدیریت ریسک‌ها." },
      { property: "og:title", content: "نقشه راه هما" },
      { property: "og:description", content: "از اعتبارسنجی ایده تا یک پلتفرم ملی خدمات ملکی." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RoadmapPage,
});

function RoadmapPage() {
  return (
    <>
      <PageHero
        kicker="نقشه راه پیشنهادی"
        title="پنج فاز، از ایده تا پلتفرم ملی"
        text="زمان‌بندی دقیق هر فاز پس از تعیین بودجه، ترکیب تیم و محدوده محصول مشخص می‌شود."
      />

      <section className="mx-auto max-w-4xl px-4 py-20 md:px-6 md:py-28">
        <ol className="relative space-y-8 border-r-2 border-primary/20 pr-8">
          {phases.map((p, i) => (
            <li key={p.title} className="relative">
              <span className="absolute -right-[49px] top-0 flex h-10 w-10 items-center justify-center rounded-full bg-gradient-brand text-sm font-black text-primary-foreground shadow-glow">
                {(i + 1).toLocaleString("fa-IR")}
              </span>
              <div className="rounded-2xl border border-border bg-card p-6 shadow-card">
                <p className="text-xs font-semibold text-primary">فاز {(i + 1).toLocaleString("fa-IR")}</p>
                <h2 className="mt-1 text-xl font-extrabold">{p.title}</h2>
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.items.map((it) => (
                    <span key={it} className="rounded-lg bg-muted px-3 py-1.5 text-sm">
                      {it}
                    </span>
                  ))}
                </div>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="bg-gradient-soft py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-4 md:px-6">
          <SectionHeading kicker="شاخص‌های ارزیابی" title="موفقیت هما را با این شاخص‌ها می‌سنجیم" />
          <div className="mt-12 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {kpis.map((k) => (
              <div key={k} className="rounded-2xl border border-border bg-card p-5 text-sm font-semibold leading-7 shadow-card">
                {k}
              </div>
            ))}
          </div>
          <div className="mt-8">
            <Notice>اهداف عددی این شاخص‌ها پس از بررسی بازار و تعیین بودجه اولیه مشخص خواهند شد.</Notice>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 md:px-6 md:py-28">
        <SectionHeading kicker="ریسک‌ها" title="ریسک‌ها را صادقانه می‌بینیم" />
        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {risks.map((r) => (
            <div key={r.title} className="rounded-2xl border border-border bg-card p-6 shadow-card">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-destructive/10 text-destructive">
                  <ShieldAlert className="h-5 w-5" />
                </span>
                <h3 className="font-bold">ریسک {r.title}</h3>
              </div>
              <p className="mt-4 text-sm leading-7 text-muted-foreground">{r.risk}</p>
              <div className="mt-4 rounded-xl bg-success-soft p-3 text-sm leading-7">
                <span className="font-bold text-success">راهکار: </span>
                {r.fix}
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
