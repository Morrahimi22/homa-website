import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Check, Layers, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Notice, PageHero, SectionHeading } from "@/components/section";
import { needs, presenters, useOfFunds } from "@/content/homa";

export const Route = createFileRoute("/invest")({
  head: () => ({
    meta: [
      { title: "پیشنهاد سرمایه‌گذاری هما | دعوت به همکاری" },
      { name: "description", content: "هما برای ساخت نسخه اولیه و آغاز فعالیت در تهران به دنبال سرمایه‌گذار است؛ سرمایه مرحله‌ای و مشروط به شاخص‌های توافق‌شده." },
      { property: "og:title", content: "پیشنهاد سرمایه‌گذاری هما" },
      { property: "og:description", content: "همراه شوید: اعتبارسنجی ایده، ساخت نسخه اولیه و توسعه تدریجی." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: InvestPage,
});

function InvestPage() {
  return (
    <>
      <PageHero
        kicker="پیشنهاد سرمایه‌گذاری"
        title="سرمایه برای ساخت نسخه اولیه و شروع از تهران"
        text="هما یک ایده کسب‌وکار در مرحله اولیه است و هنوز محصول، درآمد پایدار یا شبکه فعال مشاوران ندارد. هدف فعلی، جذب سرمایه‌گذار و تشکیل تیم تخصصی است."
      >
        <div className="flex flex-wrap gap-3 pt-2">
          <Button asChild variant="hero" size="xl">
            <Link to="/dashboard">
              ثبت علاقه به سرمایه‌گذاری <ArrowLeft />
            </Link>
          </Button>
        </div>
      </PageHero>

      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-20 md:grid-cols-2 md:px-6 md:py-28">
        <div className="rounded-3xl border border-border bg-card p-8 shadow-card">
          <h2 className="text-2xl font-extrabold">موارد استفاده از سرمایه</h2>
          <ul className="mt-6 space-y-3">
            {useOfFunds.map((u) => (
              <li key={u} className="flex gap-3 text-sm leading-7">
                <Check className="mt-1 h-4 w-4 shrink-0 text-primary" />
                {u}
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-3xl border border-border bg-card p-8 shadow-card">
          <h2 className="text-2xl font-extrabold">نیازهای اصلی پروژه</h2>
          <div className="mt-6 flex flex-wrap gap-2">
            {needs.map((n) => (
              <span key={n} className="rounded-lg bg-primary-soft px-3 py-2 text-sm text-accent-foreground">
                {n}
              </span>
            ))}
          </div>
          <p className="mt-6 text-sm leading-7 text-muted-foreground">
            یکی از تصمیم‌های مهم، انتخاب میان برون‌سپاری توسعه، تیم فنی داخلی یا مدل ترکیبی است.
          </p>
        </div>
      </section>

      <section className="bg-ink py-20 text-ink-foreground md:py-28">
        <div className="mx-auto grid max-w-7xl gap-12 px-4 md:grid-cols-2 md:px-6">
          <div className="space-y-4">
            <span className="text-sm font-semibold text-highlight">مدل پیشنهادی جذب سرمایه</span>
            <h2 className="text-balance-fa text-3xl font-extrabold leading-tight">
              به‌جای عدد و درصد بی‌پشتوانه، برآورد واقعی و سرمایه مرحله‌ای
            </h2>
            <p className="leading-8 text-ink-foreground/70">
              سرمایه‌گذاری براساس توافق طرفین، به‌صورت واگذاری بخشی از سهام یا ساختار مناسب دیگری انجام می‌شود.
            </p>
          </div>
          <ol className="space-y-4">
            {[
              "برآورد هزینه ساخت نسخه اولیه و برنامه مالی پروژه",
              "بررسی ارزش‌گذاری اولیه، سهم بنیان‌گذاران و شرایط همکاری",
              "تهیه پیشنهاد مشخص برای سرمایه‌گذار",
              "تقسیم سرمایه به مراحل: ساخت نسخه اولیه، سپس توسعه بازار، مشروط به شاخص‌های توافق‌شده",
            ].map((s, i) => (
              <li key={s} className="flex gap-4 rounded-2xl bg-ink-foreground/5 p-5">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-highlight font-black text-highlight-foreground">
                  {(i + 1).toLocaleString("fa-IR")}
                </span>
                <p className="text-sm leading-7">{s}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-4xl space-y-8 px-4 py-20 text-center md:px-6 md:py-28">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-soft text-primary">
          <Layers className="h-6 w-6" />
        </span>
        <SectionHeading
          className="mx-auto"
          title="آماده گفت‌وگو هستید؟"
          text="حساب سرمایه‌گذار بسازید و علاقه، بازه سرمایه و حوزه‌های موردنظرتان را ثبت کنید. ارائه‌دهندگان طرح با شما تماس می‌گیرند."
        />
        <Button asChild variant="hero" size="xl">
          <Link to="/dashboard">ثبت علاقه به سرمایه‌گذاری</Link>
        </Button>
        <div className="grid gap-4 text-right sm:grid-cols-2">
          {presenters.map((p) => (
            <a
              key={p.phone}
              href={`tel:${p.phone}`}
              className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5 shadow-card transition-shadow hover:shadow-elevated"
            >
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary-soft text-primary">
                <Phone className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-xs text-muted-foreground">ارائه‌دهنده طرح</span>
                <span className="block font-bold">{p.name}</span>
                <span className="block text-sm font-semibold text-primary">{p.phoneFa}</span>
              </span>
            </a>
          ))}
        </div>
        <Notice>
          هما در حال حاضر هیچ قرارداد بانکی یا توافق تأمین مالی قطعی ندارد و هیچ بازدهی سرمایه‌گذاری را تضمین نمی‌کند.
        </Notice>
      </section>
    </>
  );
}
