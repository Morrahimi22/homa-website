import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type InvestorInterest = Database["public"]["Tables"]["investor_interests"]["Row"];

export const myInterestQuery = (userId: string) =>
  queryOptions({
    queryKey: ["investor-interest", userId],
    queryFn: async () => {
      const { data, error } = await supabase.from("investor_interests").select("*").eq("user_id", userId).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

export const isAdminQuery = (userId: string) =>
  queryOptions({
    queryKey: ["is-admin", userId],
    queryFn: async () => {
      const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
      if (error) throw error;
      return !!data;
    },
  });

export const allInterestsQuery = () =>
  queryOptions({
    queryKey: ["investor-interests-all"],
    queryFn: async () => {
      const { data, error } = await supabase.from("investor_interests").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
