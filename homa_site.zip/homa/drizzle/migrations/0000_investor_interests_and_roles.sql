create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "Users read own roles" on public.user_roles
for select to authenticated using (auth.uid() = user_id);

create table public.investor_interests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique,
  full_name text not null,
  phone text not null default '',
  company text not null default '',
  investor_type text not null default 'individual',
  investment_range text not null default '',
  interest_areas text[] not null default '{}',
  message text not null default '',
  status text not null default 'new',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.investor_interests to authenticated;
grant all on public.investor_interests to service_role;
alter table public.investor_interests enable row level security;

create policy "Owners read own interest" on public.investor_interests
for select to authenticated using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "Owners insert own interest" on public.investor_interests
for insert to authenticated with check (auth.uid() = user_id);
create policy "Owners update own interest" on public.investor_interests
for update to authenticated using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'))
with check (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "Owners delete own interest" on public.investor_interests
for delete to authenticated using (auth.uid() = user_id);

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;

create trigger investor_interests_touch before update on public.investor_interests
for each row execute function public.touch_updated_at();